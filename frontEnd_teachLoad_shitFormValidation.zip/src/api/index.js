export * from './entities/auth';
export * from './entities/teachload';
export * from './entities/studyload';
export * from './entities/faculty';
export * from './entities/fsr';
export * from './entities/consulHours';
export * from './entities/adminWork';
export * from './entities/limitedpractice';
export * from './entities/publication';
export * from './entities/profchair';
export * from './entities/extension';
export * from './entities/admin';
export * from './entities/subject';

/* export * from './entities/<entity name>*/
