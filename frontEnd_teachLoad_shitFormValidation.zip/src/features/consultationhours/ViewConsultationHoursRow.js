import React, { Component } from 'react';
import 'semantic-ui-css/semantic.min.css';
import DeleteModal from '../GenericDelete';

export default class ViewConsultationHoursRow extends Component {
  render() {
    return (
      <tr>
        <td className="center aligned">{this.props.day}</td>
        <td className="center aligned"> {this.props.time} </td>
        <td className="center aligned"> {this.props.place} </td>
        <td className="center aligned">
          <DeleteModal {...this.props} />
        </td>
        <td className="center aligned">
          <button className="ui icon button">
            <i className="eye icon"> </i>
          </button>
        </td>
      </tr>
    );
  }
}
